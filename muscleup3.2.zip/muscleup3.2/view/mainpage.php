<?php

session_start();

$perfilUsu =  $_SESSION["perfilUsu"];


print_r($perfilUsu);



?>


<html>

<head>
    <link rel="stylesheet" href="../CSS/reset.css" />
    <link rel="stylesheet" href="mainpagestyle.css">
    <link rel="stylesheet" href="../CSS/main.css">

    <link href="../CSS/fontion.css" rel="stylesheet" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Jersey+25&display=swap" rel="stylesheet" />
    <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css" />
    <title>Muscle UP</title>
</head>

<body>
    <container>
        <header class="menu-principal">
            <main>
                <div class="header-1">
                    <div class="logo">
                        <a href="mainpage.php"><img src="../IMG/logo.jpg" width="90px" height="70px" /></hre>
                    </div>
                    <div class="redes-sociais">
                        <ul>
                            <li>
                                <a href=""><img src="../IMG/rss.png" /></a>
                            </li>
                            <li>
                                <a href=""><img src="../IMG/face.png" /></a>
                            </li>
                            <li>
                                <a href=""><img src="../IMG/tw.png" /></a>
                            </li>
                            <li>
                                <a href=""><img src="../IMG/linkedin.png" /></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </main>
        </header>
        <main class="col-100 menu-urls">
            <div class="header-2">
                <div class="menu">
                    <ul>


                        <?php

                            if($perfilUsu == 'Administrador'){?>

                                <li><a href="../view/cadastrarProduto.php">CADASTRAR PRODUTO</a></li>
                                <li><a href="../pagina-adm/opcao.php">PAGINA DO ADMINISTRADOR</a></li>
                        
                            <?php } ?>

                            <?php
                            if($perfilUsu == 'Funcionário'){?>

                                <li><a href="../view/cadastrarProduto.php">CADASTRAR PRODUTO</a></li>

                            <?php } ?>
                        
                        <li><a href="">LANÇAMENTOS</a></li>
                        <li><a href="">WHEY PROTEIN</a></li>
                        <li><a href="">CREATINA </a></li>
                        <li><a href=""> PRÉ-TREINO</a></li>
                        <li><a href=""> ACESSORIOS</a></li>
                        <li><a href="login.php">LOGIN </a></li>

                    </ul>
                </div>
                <div class="busca">
                    <input placeholder="Pesquise algo" type="text" />
                </div>
            </div>
        </main>
        <div class="col-100">
            <div class="slider-principal">
                <img src="../IMG/lele.jpg" width="200px" height="500px" />
                <img src="../IMG/IMG1.png" width="200px" height="500px" />
                <img src="../IMG/IMG3.png" width="200px" height="500px" />
                <img src="../IMG/IMG2.png" width="200px" height="500px" />
            </div>
        </div>
        <script type="text/javascript" src="https://code.jquery.com/jquery-1.11.0.min.js"></script>
        <script type="text/javascript" src="https://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
        <script type="text/javascript" src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js">
        </script>
        <script type="text/javascript" src="../JS/main.js"></script>
        <section class="main_blog">
            <header class="main_blog_header">
                <h1 class="icon-blog"><img src="../IMG/gabigol.png" alt="caneta" title="caneta" height="26px" /> Artigos
                    com as
                    melhores avaliações</h1>
                <p class="blog_2">
                    <br>
                    Aqui você encontra os artigos necessários para auxiliar nos seus
                    treinos.
                </p>
            </header>

            <article>
                <a href="./Project/produto.php">
                    <img src="../IMG/junio.png" width="200" alt="Imagem post" title="Imagem Post" />
                </a>
                <p><a href="" class="category">Categoria</a></p>
                <h2>
                    <a href="./view/produto.php" class="title">100% Whey protein (1Kg) - Sabor morango -
                        INTEGRALMEDICA</a>
                </h2>
            </article>

            <article>
                <a href="./Project/produto2.php">
                    <img src="./Project/img/dourado-Photoroom.png-Photoroom.png" width="200" alt="Imagem post"
                        title="Imagem Post" />
                </a>
                <p><a href="" class="category">Categoria</a></p>
                <h2>
                    <a href="./Project/produto2.php" class="title">100% Whey Protein Gold Standard (2,27Kg) - Sabor
                        Rocky Road</a>
                </h2>
            </article>

            <article>
                <a href="./Project/produto3.php">
                    <img src="./Project/img/blackSkull-Photoroom.png-Photoroom.png" width="200" alt="Imagem post"
                        title="Imagem Post" />
                </a>
                <p><a href="" class="category">Categoria</a></p>
                <h2>
                    <a href="./Project/produto3.php" class="title">Pré-Treino BLACK SKULL B.O.P.E Frutas Vermelhas
                        300g</a>
                </h2>
            </article>

            <article>
                <a href="./Project/produto4.php">
                    <img src="./Project/img/haze-Photoroom.png" width="" alt="Imagem post" title="Imagem Post" />
                </a>
                <p><a href="" class="category">Categoria</a></p>
                <h2>
                    <a href="./Project/produto4.php" class="title">Pré-Treino HAZE Hardcore 300G - GROWTH
                        SUPPLEMENTS</a>
                </h2>
            </article>

            <article>
                <a href="./Project/produto5.php">
                    <img src="./Project/img/potreico-azul-Photoroom.png-Photoroom.png" width="" alt="Imagem post"
                        title="Imagem Post" />
                </a>
                <p><a href="" class="category">Categoria</a></p>
                <h2>
                    <a href="./Project/produto5.php" class="title">Whey Protein MAX TITANIUM Pote 900g Sabor: Cookies &
                        Cream</a>
                </h2>
            </article>

            <article>
                <a href="./Project/produto6.php">
                    <img src="./Project/img/creatinaBlackSkull-Photoroom.png-Photoroom.png" width="" alt="Imagem post"
                        title="Imagem Post" />
                </a>
                <p><a href="" class="category">Categoria</a></p>
                <h2>
                    <a href="./Project/produto6.php" class="title">Creatina Monohidratada BLACK SKULL - 150G</a>
                </h2>
            </article>

            <article>
                <a href="./Project/produto7.php">
                    <img src="./Project/img/creatinaIntegral-Photoroom.png-Photoroom.png" width="" alt="Imagem post"
                        title="Imagem Post" />
                </a>
                <p><a href="" class="category">Categoria</a></p>
                <h2>
                    <a href="./Project/produto7.php" class="title">Creatina Monohidratada POWDER HARDCORE(300G)</a>
                </h2>
            </article>

            <article>
                <a href="./Project/produto8.php">
                    <img src="./Project/img/creatinaMaxtitanium-Photoroom.png-Photoroom.png" width="" alt="Imagem post"
                        title="Imagem Post" />
                </a>
                <p><a href="" class="category">Categoria</a></p>
                <h2>
                    <a href="./Project/produto8.php" class="title">Creatina 100% Pura Monohidratada - MAX TITANIUM</a>
                </h2>
            </article>
        </section>
        <div class="main_course_fullwidth" id="ancora">
            <div class="main_course_ratting_content">
                <article class="main_course_rating_title">
                    <header>
                        <h2 class="new_the_girl">
                            Melhores feedbacks da semana :)
                        </h2>
                    </header>
                    <img src="../IMG/star.png" alt="Estrela" title="Estrela" />
                    <img src="../IMG/star.png" alt="Estrela" title="Estrela" />
                    <img src="../IMG/star.png" alt="Estrela" title="Estrela" />
                    <img src="../IMG/star.png" alt="Estrela" title="Estrela" />
                    <img src="../IMG/star.png" alt="Estrela" title="Estrela" />
                </article>

                <section class="main_course_ratting_content_comment">
                    <header>
                        <h2 class="just_like">Veja o que estão falando sobre os suplementos do mercado</h2>
                    </header>
                    <article>
                        <header>
                            <h3>Guilherme Koplin <img src="../IMG/Verificado.png" alt="Verificado" title="Verificado" />
                            </h3>
                            <p>16/03/2023</p>
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                        </header>
                        <p>
                            Este suplemento é incrível! Excelente qualidade pelo preço.
                            Tenho visto resultados notáveis em minha energia e resistência nos treinos,
                            e o custo é muito justo.
                        </p>
                    </article>

                    <article>
                        <header>
                            <h3>João Lucas <img src="../IMG/Verificado.png" alt="verificado" title="verificado" /></h3>
                            <p>22/03/2023</p>
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                        </header>
                        <p>
                            Estes comprimidos de creatina são incríveis! A qualidade é top de linha e o preço é muito
                            justo.
                            Eles têm sido fundamentais para aumentar minha força e resistência nos treinos.
                        </p>
                    </article>

                    <article>
                        <header>
                            <h3>Gabriel Estevão <img src="../IMG/Verificado.png" alt="verificado" title="verificado" />
                            </h3>
                            <p>14/03/2023</p>
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                        </header>
                        <p>
                            Comprei este suplemento de colágeno para melhorar a saúde da minha pele e articulações.
                            A qualidade é excepcional e o preço é muito acessível, especialmente considerando os
                            benefícios
                            que proporciona.
                        </p>
                    </article>

                    <article>
                        <header>
                            <h3>Guilherme Messias <img src="../IMG/Verificado.png" alt="verificado"
                                    title="verificado" />
                            </h3>
                            <p>03/04/2023</p>
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                        </header>
                        <p>
                            Essas barras de proteína são deliciosas e nutritivas.
                            A qualidade dos ingredientes é excelente e o preço por unidade é bastante justo.
                            São perfeitas para um lanche rápido e saudável após o treino.
                        </p>
                    </article>

                    <article>
                        <header>
                            <h3>Ronaldo Fernandes<img src="../IMG/Verificado.png" alt="verificado" title="verificado" />
                            </h3>
                            <p>03/03/2023</p>
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                        </header>
                        <p>
                            Adquiri este multivitamínico para complementar minha dieta e estou muito satisfeito.
                            A qualidade dos ingredientes é excelente e o preço é competitivo em relação a outras
                            opções no mercado.
                        </p>
                    </article>

                    <article>
                        <header>
                            <h3>Hially Vaguetti <img src="../IMG/Verificado.png" alt="verificado" title="verificado" />
                            </h3>
                            <p>02/03/2023</p>
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                            <img src="../IMG/star.png" alt="Imagem" title="Imagem" />
                        </header>
                        <p>
                            Comprei este pré-treino recentemente e estou impressionado com a qualidade.
                            Ele realmente me dá o impulso extra que preciso para meus treinos intensos,
                            e o preço é muito mais razoável do que outras marcas.
                        </p>
                    </article>
                </section>
            </div>
        </div>
        </section>
        <section class="main_footer">
            <header>
                <h1>Quer saber mais?</h1>
            </header>

            <article class="main_footer_our_pages">
                <header>
                    <h2>Nossas Páginas</h2>
                </header>
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Blog</a></li>
                    <li><a href="#">Contato</a></li>
                </ul>
            </article>

            <article class="main_footer_links">
                <header>
                    <h2>Links Úteis</h2>
                </header>
                <ul>
                    <li><a href="#">Política de Privacidade</a></li>
                    <li><a href="#">Aviso Legal</a></li>
                    <li><a href="#">Termos de Uso</a></li>
                </ul>
            </article>

            <article class="main_footer_about">
                <header>
                    <h2>Sobre o Projeto</h2>
                </header>
                <p>
                    Aprenda sobre suplementos conosco e dê sua opinião!
                </p>
            </article>
        </section>
        <!-- FIM DOBRA RODAPÉ -->
</body>
<script>
// Seleciona o link e a janela modal
var link = document.querySelector(".modal-link");
var modal = document.querySelector(".modal");
var overlay = document.querySelector(".overlay");

// Adiciona um listener de evento para o link
link.addEventListener("click", function(event) {
    event.preventDefault(); // previne o comportamento padrão do link (navegar para outra página)

    overlay.style.display = "block"; // exibe a camada escura
    modal.style.display = "block"; // exibe a janela modal
});

// Adiciona um listener de evento para a camada escura
overlay.addEventListener("click", function() {
    overlay.style.display = "none"; // oculta a camada escura
    modal.style.display = "none"; // oculta a janela modal
});
</script>
</container>
<footer class="main_footer_rights">
    <p class="bazinga">MuscleUP - Todos os direitos reservados.</p>
</footer>

</body>

</html>