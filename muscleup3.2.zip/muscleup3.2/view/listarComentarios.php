
<?php

require_once     '../controler/mostraComentariosController.php';
   // require_once 'model/DAO/ComentarioDAO.php';

   // var_dump($todos);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Comentarios Cadastrados</h1>

    <?php
        foreach($todos as $t){ ?>

        <h1><?php echo " {$t['tituloCom']}" ?></h1>
        <p><?php echo " {$t['textoCom']}" ?></p>

        <?php } ?>
    
</body>
</html>