<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=
    , initial-scale=1.0">
    <title>Home</title>
</head>
<body>
    <ul>
        <li>Menu</li>
      <a href="view/cadastrarUsuario.php"><li>Cadastrar usuario</li></a>  
    </ul>
</body>
</html>