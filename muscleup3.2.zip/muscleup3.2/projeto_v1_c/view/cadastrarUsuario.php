<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Usuário</title>
</head>

<body>
    <h1>Cadastro de Usuário</h1>

    <form action="../control/cadastrarUsuarioController.php" method="post">
        Nome: <input type="text" name="nomeUsu" required><br>
        senha: <input type="password" name="senhaUsu"><br>
        email: <input type="email" name="emailUsu"><br>
        <input type="submit" value="Cadastrar">
    </form>
</body>

</html>