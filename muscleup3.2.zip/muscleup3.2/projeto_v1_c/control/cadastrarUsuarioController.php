<?php
require_once '../model/DAO/UsuarioDAO.php';
require_once '../model/DTO/UsuarioDTO.php';

//receber os dados do formulario
$nomeUsuario = $_POST["nome"];
$emailUsuario = $_POST["email"];
$senhasuario = $_POST["senha"];

//criar o objeto DTO para armazenar os dados do formulario
$usuarioDTO = new UsuarioDTO();

$usuarioDTO->setNomeUsu($nomeUsuario);
$usuarioDTO->setEmailUsu($emailUsuario);
$usuarioDTO->setSenhaUsu($senhaUsuario);

//criar o objeto que gravará os dados no banco
$usuarioDAO = new UsuarioDAO();

$sucesso = $usuarioDAO->salvarUsuario($usuarioDTO);

if($sucesso){
    $msg  = "Cadastro realizado";
}else{
    $msg  = "Cadastro não realizado";
}
echo "{$msg}";





?>