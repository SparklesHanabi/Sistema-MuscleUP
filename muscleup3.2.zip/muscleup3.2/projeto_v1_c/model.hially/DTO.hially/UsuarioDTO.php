<?php
    class UsuarioDTO{
        private $nomeUsu;
        private $senhaUsu;
        private $emailUsu;

        public function setNomeUsu($nomeUsu){
            $this->nomeUsu = $nomeUsu;
        }
        public function getNomeUsu(){
            return $this->nomeUsu;
        }
        public function setSenhaUsu($senhaUsu){
            $this->senhaUsu = $senhaUsu;
        }
        public function getSenhaUsu() {
            return $this->senhaUsu;
        }   
        public function setEmailUsu($emailUsu){
            $this->emailUsu = $emailUsu;
        }
        public function getEmailUsu() {
            return $this->emailUsu;
        } 
    }
?>