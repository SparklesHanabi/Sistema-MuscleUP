<?php
    include 'Conexao.php';
    require_once '../model/DTO/UsuarioDTO.php';
    class UsuarioDAO{
        public $pdo = null;

        public function __construct(){
            $this->pdo = Conexao::getInstance();
        }
        public function salvarUsuario(UsuarioDTO $usuarioDTO){

            try{
                $sql = "INSERT INTO usuario (nomeUsu, cpfUsu) VALUES (?,?)";

                $stmt = $this->pdo->prepare($sql);
    
                $nomeUsu = $usuarioDTO->getNomeUsu();
                $cpfUsu = $usuarioDTO->getCpfUsu();
    
                $stmt->bindValue(1, $nomeUsu);
                $stmt->bindValue(2, $cpfUsu);
    
                $retorno = $stmt->execute();
                return  $retorno;

            }catch(PDOException $exc){
                echo $exc->getMessage();
            }

        }
    }

?>