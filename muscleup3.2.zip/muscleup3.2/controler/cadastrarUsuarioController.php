<?php
require_once '../model/DAO/UsuarioDAO.php';
require_once '../model/DTO/UsuarioDTO.php';

//receber os dados do formulario
$nomeUsu = strip_tags($_POST["nomeUsu"]);
$emailUsu = strip_tags($_POST["emailUsu"]);
$senhaUsu = MD5($_POST["senhaUsu"]);


//criar o objeto DTO para armazenar os dados do formulario
$usuarioDTO = new UsuarioDTO();

$usuarioDTO->setNomeUsu($nomeUsu);
$usuarioDTO->setEmailUsu($emailUsu);
$usuarioDTO->setSenhaUsu($senhaUsu);

//echo "<pre>";
//var_dump($usuarioDTO);
//echo "</pre>";


//criar o objeto que gravará os dados no banco
$usuarioDAO = new UsuarioDAO();

$sucesso = $usuarioDAO->salvarUsuario($usuarioDTO);

if ($sucesso) {
    $msg = "Cadastro realizado";
    header("location:../view/login.php?msg=$msg");
} else {
    $msg = "Cadastro não realizado";
}
header("location:../index.php?msg=$msg");


?>