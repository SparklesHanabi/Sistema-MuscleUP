<?php

    include_once '../model/DTO/ComentarioDTO.php';
    include_once '../model/DAO/ComentarioDAO.PHP';

    $tituloCom = $_GET["tituloCom"];
    $textoCom = $_GET["textoCom"];

    //montar o objeto

    $comentarioDTO = new ComentarioDTO();

    $comentarioDTO->setTextoCom($textoCom);
    $comentarioDTO->setTituloCom($tituloCom);

  //  var_dump($comentarioDTO);

    $comentarioDAO = new ComentarioDAO();

    $sucesso = $comentarioDAO->salvarComentario($comentarioDTO);

    if($sucesso){
        header('Location:../index.php');
    }



?>