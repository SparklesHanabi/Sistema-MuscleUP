<?php
class ComentarioDTO{

    private $idCom;
    private $textoCom;
    private $tituloCom;
    //private $linkCom;
 

    function getIdCom(){
        return $this->idCom;

    }
    function getTextoCom(){
        return $this->textoCom;

    }
    function getTituloCom(){
        return $this->tituloCom;
    }
  /*  function getLinkCom(){
        return $this->linkCom;
    }*/
    function setIdCom($idCom){
        $this->idCom = $idCom;
    }
    function setTextoCom($textoCom){
        $this->textoCom = $textoCom;
    }
    function setTituloCom($tituloCom){
        $this-> tituloCom = $tituloCom;
    }
  /*  function setLinkCom($linkCom){
        $this-> linkCom = $linkCom;
    }*/
}


?>