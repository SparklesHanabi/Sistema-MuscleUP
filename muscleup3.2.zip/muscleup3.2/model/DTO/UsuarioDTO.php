<?php
    class UsuarioDTO{
        private $idUsu;
        private $nomeUsu;
        private $senhaUsu;
        private $emailUsu;
        private $telefoneUsu;

        public function setIdUsu($idUsu){
            $this->idUsu = $idUsu;
        }
        public function getIdUsu(){
            return $this->idUsu;
        }
        //
        public function setNomeUsu($nomeUsu){
            $this->nomeUsu = $nomeUsu;
        }
        public function getNomeUsu(){
            return $this->nomeUsu;
        }
        public function setSenhaUsu($senhaUsu){
            $this->senhaUsu = $senhaUsu;
        }
        public function getSenhaUsu() {
            return $this->senhaUsu;
        }   
        public function setEmailUsu($emailUsu){
            $this->emailUsu = $emailUsu;
        }
        public function getEmailUsu() {
            return $this->emailUsu;
        } 
    }
?>