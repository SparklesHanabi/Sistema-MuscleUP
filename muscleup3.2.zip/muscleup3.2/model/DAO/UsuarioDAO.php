<?php
include 'Conexao.php';
require_once '../model/DTO/UsuarioDTO.php';
class UsuarioDAO
{
    public $pdo = null;

    public function __construct()
    {
        $this->pdo = Conexao::getInstance();
    }
    public function salvarUsuario(UsuarioDTO $usuarioDTO)
    {

        try {
            $sql = "INSERT INTO usuario (nomeUsu, senhaUsu, emailUsu) VALUES (?,?,?)";

            $stmt = $this->pdo->prepare($sql);

            $nomeUsu = $usuarioDTO->getNomeUsu();
            $senhaUsu = $usuarioDTO->getSenhaUsu();
            $emailUsu = $usuarioDTO->getEmailUsu();

            $stmt->bindValue(1, $nomeUsu);
            $stmt->bindValue(2, $senhaUsu);
            $stmt->bindValue(3, $emailUsu);

            $retorno = $stmt->execute();
            return $retorno;

        } catch (PDOException $exc) {
            echo $exc->getMessage();
        }

    }

    public function validarLogin($emailUsu,$senhaUsu) {
        //echo "{$emailUsu}";
        //echo "{$senhaUsu}";
        try {
            $sql = "SELECT * FROM usuario WHERE emailUsu = '{$emailUsu}' AND
             senhaUsu = '{$senhaUsu}'; ";
            $stmt = $this->pdo->prepare($sql);
            
            $stmt->execute();
              $retorno = $stmt->fetch(PDO::FETCH_ASSOC); 
            return $retorno;
         } catch (PDOException $exc) {
            echo $exc->getMessage();  
         }
      }


}

?>